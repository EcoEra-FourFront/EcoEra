# E-waste > E-waste
https://universe.roboflow.com/object-detection/e-waste-mx8fq

Provided by a Roboflow user
License: CC BY 4.0

